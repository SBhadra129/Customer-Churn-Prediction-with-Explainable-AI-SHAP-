import streamlit as st
import pandas as pd
import joblib

st.title("📊 Churn Prediction with Explainability")

model = joblib.load("models/model.pkl")

tenure = st.slider("Tenure",1,72)
monthly = st.number_input("Monthly Charges",0.0,200.0)
total = st.number_input("Total Charges",0.0,10000.0)

if st.button("Predict"):
    df = pd.DataFrame([[tenure,monthly,total]],columns=["tenure","MonthlyCharges","TotalCharges"])
    pred = model.predict(df)[0]
    st.success("Churn" if pred==1 else "No Churn")
