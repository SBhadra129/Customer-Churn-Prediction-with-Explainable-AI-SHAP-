# 📊 Customer Churn Prediction with SHAP

This project predicts churn and explains model decisions using SHAP.

## Run
pip install -r requirements.txt
python src/train.py
streamlit run app/streamlit_app.py
