import shap
import joblib
import pandas as pd

model = joblib.load("models/model.pkl")

data = pd.DataFrame({
    "tenure":[1,12,24],
    "MonthlyCharges":[20,50,70],
    "TotalCharges":[20,600,1680]
})

explainer = shap.Explainer(model, data)
shap_values = explainer(data)

shap.plots.beeswarm(shap_values)
