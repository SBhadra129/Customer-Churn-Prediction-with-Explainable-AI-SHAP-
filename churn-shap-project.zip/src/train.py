import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import joblib

# Dummy dataset
data = {
    "tenure":[1,12,24,36,48,60],
    "MonthlyCharges":[20,50,70,80,90,100],
    "TotalCharges":[20,600,1680,2880,4320,6000],
    "Churn":[1,0,0,0,1,0]
}

df = pd.DataFrame(data)

X = df.drop("Churn", axis=1)
y = df["Churn"]

model = RandomForestClassifier()
model.fit(X,y)

joblib.dump(model,"models/model.pkl")
print("Model trained and saved")
